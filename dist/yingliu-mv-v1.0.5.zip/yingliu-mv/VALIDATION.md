# 验证记录

日期：2026-10-22。版本：1.0.5（在 1.0.4 基础上按用户流程重构：六步叙述、对标拆解、全能参考、交付改用片段音频）。

## 1.0.5 验证

- 新增 `references/baseline-video.md`：对标视频拆解卡，结论写入 `concept.json` 的 `baseline`。
- `project.json` 新增 `reference_video`、`reference_voice`、`delivery_audio`；`design.json` 新增可选 `global.omni_reference`（每项须含 `asset` 与 `role`，结构不合规即阻断）。
- `render --mode final` 默认拼接片段自带音频，母带不再重贴；`delivery_audio=master` 可回退。片段缺音轨时报错。
- 演练夹具改为生成带音轨的合成片段，覆盖新交付路径。

## 1.0.4 验证

- `state/design.json` 未声明 `"method": "zy-cinematic-realism"` 时，`compile`、`render --mode preview`、`pack --shot` 直接抛错阻断；已加入对应单元测试。
- `python -X utf8 -m unittest discover -s tests -v`：全部通过。
- `python scripts/mv.py doctor --smoke`：local_ready=true，issues=0。
- 重新打包 `dist/yingliu-mv-v1.0.4.zip` 并重跑 ZIP 隔离安装演练：`status=passed`，13 项检查全部通过，62 条命令，8 秒 / 192 帧成片，母带逐样本哈希一致；安装副本含 vendor 77 文件。
- README 补充六阶段流程图、阶段产物表、三个硬闸门与命令时序后重打包复验，结论不变；`dist/` 只保留 1.0.4 分发包。

## 1.0.3 验证

## 1.0.3 验证

- `python scripts/mv.py doctor --smoke`：local_ready=true，issues=0。
- `python -X utf8 -m unittest discover -s tests -v`：12 项全部通过。
- `vendor/zy-cinematic-realism/`：77 个文件、40 张导演卡，LICENSE / NOTICE.md / SKILL.md 完整。
- 新增 `references/zy-cinematic-integration.md`：映射到 `design.json` 的 `global`/`scenes`/`shots`，不引用本版已不存在的旧脚本与状态文件。
- 重新打包 `dist/yingliu-mv-v1.0.3.zip`（99 个文件）并完成 ZIP 隔离安装演练：`status=passed`，13 项检查全部通过，62 条 CLI 命令，8 秒 / 192 帧成片完整解码，母带逐样本哈希一致；安装副本含 `vendor/zy-cinematic-realism/` 77 个文件与 ZY 集成文档。

## 1.0.2 验证

- `python -X utf8 -m unittest discover -s tests -v`：12 项通过（含依赖缺失、路径、缓存失效、帧量化和媒体链路）。
- skill-creator `quick_validate.py`：Skill is valid!
- `python scripts/mv.py doctor --smoke`：当前环境 Python 3.14.3、FFmpeg/FFprobe 8.1，以及所需编码器、解码器、滤镜、封装能力均通过；实际完成合成、ALAC音频、抽帧、拼接。
- 模拟未安装、无法启动和缺少编码器的环境，均返回 local_ready=false。外部能力保持 unverified。
- 核心脚本通过 Python 3.10 语法兼容检查；实际执行环境为 Python 3.14.3，未在其他系统或 Python 3.10 解释器上运行。
- 实际使用 FFmpeg 生成两秒合成音频、图片与视频，完成预演、抽帧、样片记录、选段、母带合成和交付状态链。
- 验证原曲变化使批准失效、静帧观察不能作为动态通过、媒体替换使观察过期、图片变化使旧预演失效、项目初始化不覆盖已有目录、项目路径越界拒绝。

所有审查者和批准均为隔离合成测试声明，不代表真实观看、真实口型通过或真实影片验收。未运行付费生成、真实 ASR 或宿主 Agent 视觉；未测量真实制作 token 节省比例。未修改或发布原工作流，未安装到全局 Skill 目录。

新增 ZIP 新用户演练：使用独立模拟主目录安装、在另一目录调用 CLI，完成六阶段模拟；8秒、640×360、24fps、192帧实际出片，完整解码成功，成片解码音频与母带哈希一致。具体操作见 references/new-user.md，修复记录见 NEW_USER_AUDIT.md。模拟状态固定为 simulation_completed，不作为真实生产批准。
